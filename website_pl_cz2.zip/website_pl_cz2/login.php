<?php
session_start();

if((!isset($_POST['login'])) || (!isset($_POST['password'])))
{
    header('Location: strona5.php');
    exit();
}

require_once "connect.php";

$connection = @new mysqli($host, $db_user, $db_password, $db_name);

if($connection->connect_errno!=0)
{
    echo "Error: ".$connection->connect_errno;
}
else
{
    $login = $_POST['login'];
    $password = $_POST['password'];
    
    $sql="SELECT * FROM user WHERE user='$login' AND password='$password'";
    
   
    
    if ($result = @$connection->query($sql))
    {
        $numberofusers = $result->num_rows;
        if($numberofusers>0)
        {
            $_SESSION['signin'] = true;
            $_SESSION['id'] = $row['id'];
            $row = $result->fetch_assoc();
            $_SESSION['usero'] = $row['user'];
            $_SESSION['email'] = $row['e-mail'];
            
            
           
                
            }
            unset($_SESSION['error']);
            $result->close();
            header('Location: page5.php');
        }
        else 
        {
            $_SESSION['error'] = '<span style="color:red">Wrong login or password!</span>';
            header('Location: page4.php');
        }
        
        
    }
    
    $connection->close();




?>