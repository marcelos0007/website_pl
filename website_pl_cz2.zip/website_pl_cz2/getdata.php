<! DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>website design by David</title>
        <meta name="description" content="web design">
        <link rel="stylesheet" href="style.css">
        
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript" src="javascript.js"></script>
    
    
        
    </head>
    <body onload="timer();">
        
      <div class="container">
        
        <p><center>
            <a href="strona1.html"><img src="photos/LA2.jpg" width="348px" height="224px"></a>
            </center></p>
          
        <br>
        <div class="menu">
        
        <div class="option" style="border-left: 2px dotted;">
            
        <a href="strona1.html" style="text-decoration:none" style="border-left: 2px dotted" >Main Page</a>
        </div>
        
        <div class="option">
            <a href=strona2.html style="text-decoration: none">History</a>
        </div>
        
        <div class="option"><a href=strona3.html style="text-decoration: none">Attractions</a></div>
        
        <div class="option"><a href=strona4.html style="text-decoration: none">Photos</a>
        </div>
        <div class="option"><a href="strona5.html" style="text-decoration:none">Contact</a></div>
        <div style="clear: both"></div>
    </div>
        <br>
<!------------THIS IS MY CONTENT------------>
        <div id="content">
        <div class="contentL">
            <img src="photos/lamp.jpg" width="240" height="130" ></div>
          <div class="contentR">  
        -We can design, implement and solve problems in web development
        <p>-Mail to us on address: d.kalwa.student@gmail.com</p>
        <p>-Phone number: 512 346 111</p></div>
        
            <div style="clear:both"></div>
        </div>
          <br>
          <div id="conmap">
          <div id="map"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3515.8534719537292!2d17.90266646357282!3d50.65424183547162!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x471053bb1bcdafab%3A0xf2ef41915344d5dd!2sPolitechnika+Opolska!5e0!3m2!1spl!2spl!4v1522234103830" width="400" height="300" frameborder="0" style="border:0" allowfullscreen></iframe></div>
              
        <div class="mapr">On this map you can see the localization of our company.
        <br><br>Address: Prószkowska 76 street, 45-758 Opole<br>NIP: 754-00-08-109
        <br><br><div style="font-size: 24px">Open Hours:</div>
        <br>Tuesday–Friday: 11:00 a.m.–3:00 p.m.<br>
            Thursday Evenings: 6:00–9:30 p.m.<br>
            Saturday–Sunday: 11:00 a.m.–4:00 p.m.</div>
              
          <div id="clock"></div>
        
        <div style="clear:both"></div>
              <br>
              <?php
// define variables and set to empty values
$nameErr = $emailErr = $miastoErr = $phoneErr = "";
$name = $email = $miasto = $haslo = $phone = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed"; 
    }
  }
  
    
    
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format"; 
    }
  }
    
  
    
    if (empty($_POST["phone"])) {
    $comment = "";
  } else {
    $phone = test_input($_POST["phone"]);
  }
 if (empty($_POST["haslo"])) {
    $comment = "";
  } else {
    $haslo = test_input($_POST["haslo"]);
  }
     if (empty($_POST["miasto"])) {
    $comment = "";
  } else {
    $miasto = test_input($_POST["miasto"]);
  }
  
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
        
                  
              
           
             
<h1>Our feedback:</h1>
             <?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "baza");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$login = mysqli_real_escape_string($link, $_REQUEST['login']);
$job = mysqli_real_escape_string($link, $_REQUEST['job']);
$salary = mysqli_real_escape_string($link, $_REQUEST['salary']);
 
// attempt insert query execution
$sql = "INSERT INTO job (login, job, salary) VALUES ('$login', '$job', '$salary')";
if(mysqli_query($link, $sql)){
    echo "Records added successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// close connection
mysqli_close($link);
?>

<div class="footer">Code better! &copy; 2018 David Kalwa All Rights Reserved. </div>
          </div>
 </div>
    </body>
</html>