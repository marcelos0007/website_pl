<?php

$host = "localhost";
$db_user = "root";
$db_password = "";
$db_name = "baza";

?>

/*<?php

$host = "mysql1.ugu.pl";
$db_user = "db693378";
$db_password = "Opole123";
$db_name = "db693378";

?>*/
